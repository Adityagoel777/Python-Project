from flask import Flask
from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

def create_app():
    app = Flask(__name__)
    app.config.from_object('app.config.Config')
    db.init_app(app)
    
    with app.app_context():
        from . import routes, errors  # Register routes and error handlers
        db.create_all()              # Initialize database tables
        
    return app
