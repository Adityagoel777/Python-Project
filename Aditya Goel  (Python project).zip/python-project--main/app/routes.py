from flask import Blueprint, request, jsonify
from .models import db, EngagementPost, Product, EngagementPostContent

routes = Blueprint('routes', __name__)

@routes.route('/api/posts/<int:tenant_id>', methods=['GET'])
def get_posts(tenant_id):
    try:
        posts = db.session.execute(
            """
            SELECT ep.enagement_post_id, ep.title, ep.thumbnail_url, epc.content_url, p.product_name, p.product_image
            FROM engagement_post ep
            LEFT JOIN engagement_post_content epc ON ep.enagement_post_id = epc.engagement_post_id
            LEFT JOIN product p ON ep.enagement_post_id = p.engagement_post_id
            WHERE ep.tenant_id = :tenant_id;
            """, {'tenant_id': tenant_id}
        ).fetchall()
        return jsonify([dict(row) for row in posts]), 200
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@routes.route('/api/products', methods=['POST'])
def create_product():
    try:
        data = request.json
        new_product = Product(
            product_name=data['product_name'],
            product_image=data['product_image'],
            sku=data['sku']
        )
        db.session.add(new_product)
        db.session.commit()
        return jsonify({'product_id': new_product.product_id}), 201
    except Exception as e:
        return jsonify({'error': str(e)}), 500
