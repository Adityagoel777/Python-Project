from . import db

class EngagementPost(db.Model):
    __tablename__ = 'engagement_post'
    enagement_post_id = db.Column(db.Integer, primary_key=True)
    tenant_id = db.Column(db.Integer, nullable=False)
    title = db.Column(db.String, nullable=False)
    thumbnail_url = db.Column(db.String, nullable=True)

class Product(db.Model):
    __tablename__ = 'product'
    product_id = db.Column(db.Integer, primary_key=True)
    product_name = db.Column(db.String, nullable=False)
    product_image = db.Column(db.String, nullable=False)
    sku = db.Column(db.String, nullable=False)
    engagement_post_id = db.Column(db.Integer, db.ForeignKey('engagement_post.enagement_post_id'))

class EngagementPostContent(db.Model):
    __tablename__ = 'engagement_post_content'
    content_id = db.Column(db.Integer, primary_key=True)
    engagement_post_id = db.Column(db.Integer, db.ForeignKey('engagement_post.enagement_post_id'))
    content_url = db.Column(db.String, nullable=False)
