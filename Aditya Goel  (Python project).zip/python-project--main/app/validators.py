from flask import jsonify

def validate_product_data(data):
    if not data.get('product_name') or not data.get('product_image') or not data.get('sku'):
        return jsonify({'error': 'Missing required fields'}), 400
    return None
