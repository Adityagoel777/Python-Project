class Config:
    SQLALCHEMY_DATABASE_URI = 'postgresql://username:password@localhost/engagement'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SECRET_KEY = 'your-secret-key'
